package abc.sound;

import static org.junit.Assert.*;

import org.junit.Test;

public class SequencePlayerTest {

    // TODO: warmup #2
    
    @Test
    public void test() {
        fail("Not yet implemented");
    }
    

}
